<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="de_DE">
<context>
    <name>QObject</name>
    <message>
        <location filename="hello.cpp" line="24"/>
        <source>Hello</source>
        <translatorcomment>Begrüßung</translatorcomment>
        <translation>Hallo</translation>
    </message>
</context>
</TS>
