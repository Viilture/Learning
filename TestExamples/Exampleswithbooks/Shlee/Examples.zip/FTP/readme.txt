In order to compile these examples, use at least Qt 5.10.0. 

The commands to build the examples for Windows, Mac OS X and Linux:
Windows (MinGW C++) : qmake
                      mingw32-make

Windows (Visual C++) : qmake
                       nmake

Mac OS X: qmake -spec macx-clang; make

Linux: qmake; make

Note: 
  You can also use for the compiling "Qt Creator"
